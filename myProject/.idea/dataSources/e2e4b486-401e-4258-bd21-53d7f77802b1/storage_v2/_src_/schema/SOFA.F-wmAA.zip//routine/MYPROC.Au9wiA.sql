create procedure myProc AS

i number;
begin
  for i in 1..120 loop
  insert into t_pa_product ( (FID+i )    ,         
  FSET_CODE        ,
  FCODE            ,
  FNAME           ,
  FALIAS            ,
  FNAME_ENG           ,
  FPRODUCT_TYPE      ,
  FMANAGER           ,
  FCUSTODIAN        ,
  FCONTRACT_BEG_DATE  ,
  FCONTRACT_END_DATE  ,
  FFACT_BEG_DATE      ,
  FFACT_END_DATE    ,
  FLEAF             ,
  FCREATOR_ID       ,
  FCREATE_TIME      ,
  FDELETED         ,
  FPRO_TOPTYPE     ,
  FOPERATION_UNIT  )
   select  FID +i  ,           
  FSET_CODE        ,
  FCODE            ,
  FNAME           ,
  FALIAS            ,
  FNAME_ENG           ,
  FPRODUCT_TYPE      ,
  FMANAGER           ,
  FCUSTODIAN        ,
  FCONTRACT_BEG_DATE  
  FCONTRACT_END_DATE  ,
  FFACT_BEG_DATE      ,
  FFACT_END_DATE    ,
  FLEAF             ,
  FCREATOR_ID       ,
  FCREATE_TIME      ,
  FDELETED         ,
  FPRO_TOPTYPE     ,
  FOPERATION_UNIT   from t_pa_product
end
  /

