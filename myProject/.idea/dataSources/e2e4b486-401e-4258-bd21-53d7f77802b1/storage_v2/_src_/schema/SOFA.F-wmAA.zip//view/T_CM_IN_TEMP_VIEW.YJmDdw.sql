create view T_CM_IN_TEMP_VIEW as
select a.fuser_id,a.fdatarole_id,a.fcheck_state as fuserrole_check_state,
  b.fauth_code,b.fpropertygroup_code,b.fdata_value,b.fcheck_state as froledata_check_state
from sofa.T_ACL_USERROLE a left join sofa.T_ACL_ROLEDATA b
on a.fdatarole_id = b.frel_id
where a.fcheck_state = 1 and b.fcheck_state = 1
/

