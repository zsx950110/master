create view V$_DEMOVO as
select "EMPLOYEE_ID","CODE","NAME","MANAGER_ID" from demovo
/

