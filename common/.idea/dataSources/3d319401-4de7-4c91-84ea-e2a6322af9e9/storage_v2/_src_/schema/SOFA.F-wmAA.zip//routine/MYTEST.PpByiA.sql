create procedure mytest(para in number );

begin
declare ret demovo%rowtype;

select * into ret from demovo where code=para;
dbms_output.put_line(ret.code);
end;
/

