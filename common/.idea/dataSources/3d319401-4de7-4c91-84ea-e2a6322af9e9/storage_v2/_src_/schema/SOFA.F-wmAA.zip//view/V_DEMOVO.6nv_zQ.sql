create view V$DEMOVO as
select name from demovo where code=324
/

