create view V1$_DEMOVO as
select "EMPLOYEE_ID","CODE","NAME","MANAGER_ID" from demovo with read only
/

